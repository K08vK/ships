﻿using System;

class Player
{
    public string Name { get; set; }
    public Board OwnBoard { get; set; }
    public Board TargetBoard { get; set; }

    public Player(string name)
    {
        Name = name;
        OwnBoard = new Board();
        TargetBoard = new Board();
    }
}

class Board
{
    private const int Size = 10;
    public char[,] grid; 

    public Board()
    {
        grid = new char[Size, Size];
        InitializeBoard();
    }

    private void InitializeBoard()
    {
        for (int i = 0; i < Size; i++)
        {
            for (int j = 0; j < Size; j++)
            {
                grid[i, j] = '.'; 
            }
        }
    }

    public void Display()
    {
        Console.WriteLine("    0 1 2 3 4 5 6 7 8 9");
        for (int i = 0; i < Size; i++)
        {
            Console.Write($"{i} |");
            for (int j = 0; j < Size; j++)
            {
                Console.Write($" {grid[i, j]}"); 
            }
            Console.WriteLine();
        }
    }

    public bool PlaceShip(int row, int col, int size, char direction)
    {
        if (row < 0 || row >= Size || col < 0 || col >= Size)
        {
            Console.WriteLine("Umieszczenie statku poza granicami.");
            return false;
        }

        if (!IsShipPlacementValid(row, col, size, direction))
        {
            Console.WriteLine("Umieszczenie statku koliduje z innym statkiem.");
            return false;
        }

        if (direction == 'H') 
        {
            for (int i = 0; i < size; i++)
            {
                grid[row, col + i] = 'S';
            }
        }
        else if (direction == 'V')
        {
            for (int i = 0; i < size; i++)
            {
                grid[row + i, col] = 'S';
            }
        }
        else
        {
            Console.WriteLine("Nieprawidłowy kierunek.");
            return false;
        }

        return true;
    }

    private bool IsShipPlacementValid(int row, int col, int size, char direction)
    {
        if (row < 0 || row >= Size || col < 0 || col >= Size)
        {
            return false;
        }

        if (direction == 'H') 
        {
            for (int i = 0; i < size; i++)
            {
                if (col + i >= Size || grid[row, col + i] != '.')
                {
                    return false;
                }
            }
        }
        else if (direction == 'V') 
        {
            for (int i = 0; i < size; i++)
            {
                if (row + i >= Size || grid[row + i, col] != '.')
                {
                    return false;
                }
            }
        }
        else
        {
            return false;
        }

        return true;
    }


    public bool Shoot(int row, int col)
    {
        if (row < 0 || row >= Size || col < 0 || col >= Size)
        {
            Console.WriteLine("Nieprawidłowe koordynaty strzału.");
            return false;
        }

        if (grid[row, col] != '.' && grid[row, col] != 'S') 
        {
            Console.WriteLine("Już strzelałeś w to miejsce.");
            return false;
        }

        if (grid[row, col] == 'S')
        {
            grid[row, col] = 'X'; 
            return true;
        }
        else
        {
            grid[row, col] = 'O';
            return false;
        }
    }

}

class Ship
{
    public int Size { get; set; }
    public bool IsSunk { get; set; }

    public Ship(int size)
    {
        Size = size;
        IsSunk = false;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("WITAMY W GRZE 'STATKI'");

        Player player1 = new Player("1");
        Player player2 = new Player("2");

        SetupBoards(player1);
        Console.Clear();
        Console.ReadKey();
        SetupBoards(player2);

        Player currentPlayer = player1;
        Player opponent = player2;

        

        while (!GameIsOver(player1, player2))
        {
            Console.Clear();
            Console.ReadKey();
            Console.WriteLine($"Tura {currentPlayer.Name}ego gracza");
            Console.WriteLine("Twoja Plansza:");
            currentPlayer.OwnBoard.Display();
            Console.WriteLine("Twoje Strzały:");
            currentPlayer.TargetBoard.Display();

            Console.WriteLine("Podaj koordynaty aby oddać strzał (np. 00(wiersz kolumna)):");
            string input = Console.ReadLine().ToUpper();
            if (input.Length == 2 && char.IsDigit(input[1]) && char.IsDigit(input[0]))
            {
                int row = input[1] - '0';
                int col = input[0] - '0';
                bool shotResult = opponent.OwnBoard.Shoot(row, col);

                if (shotResult)
                {
                    Console.WriteLine("Trafiony!");
                    currentPlayer.TargetBoard.grid[row, col] = 'X';
                    if (CheckIfShipSunk(opponent.OwnBoard, row, col))
                    {
                        Console.WriteLine("Trafiony zatopiony!");
                    }
                }else
                {
                    Console.WriteLine("Pudło!");
                    currentPlayer.TargetBoard.grid[row, col] = 'O';
                    Player temp = currentPlayer;
                    currentPlayer = opponent;
                    opponent = temp;
                }
            }
            else
            {
                Console.WriteLine("Nieprawidłowe dane wejściowe. Proszę wprowadzić współrzędne w formacie '00'.");
            }

            Console.WriteLine("Naciśnij jakikolwiek przycisk...");
            Console.ReadKey();
        }

        Console.WriteLine("Koniec gry!");
    }

    static private bool CheckIfShipSunk(Board board, int row, int col)
    {
        char shipSymbol = board.grid[row, col];
        int size = 0;
        
        for (int i = 0; i < board.grid.Length; i++)
        {
            for (int j = 0; j < board.grid.Length; j++)
            {
                try
                {
                    if (board.grid[i, j] == shipSymbol)
                    {
                            return false;
                    }
                }
                catch (Exception)
                {

                }
            }
        }
        return true;
    }

    static void SetupBoards(Player player)
    {
        Console.WriteLine($"Plansza konfiguracyjna gracza {player.Name}");

        PlaceShipsInSequence(player.OwnBoard);
    }

    static void PlaceShipsInSequence(Board board)
    {
        PlaceShipSequentially(board, 1, 4);
        PlaceShipSequentially(board, 2, 3);
        PlaceShipSequentially(board, 3, 2);
        PlaceShipSequentially(board, 4, 1);
    }

    static void PlaceShipSequentially(Board board, int shipCount, int shipSize)
    {
        for (int i = 0; i < shipCount; i++)
        {
            bool placed = false;
            while (!placed)
            {
                Console.WriteLine($"Umieść statek o rozmiarze: {shipSize}.");
                Console.WriteLine("Podaj koordynaty (wiersz, kolumny) dla punktu startowego statku:");
                int row = 0;
                int col = 0;
                char direction = 'h';
                bool end = false;
                do
                {
                    try
                    {
                        Console.Write("Wiersz: ");
                        row = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Kolumna: ");
                        col = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Podaj kierunek (H poziomo, V pionowo):");
                        direction = Convert.ToChar(Console.ReadLine().ToUpper());
                        end = true;
                    }
                    catch (Exception)
                    {

                    }
                } while (!end); 
                if (!AdjacentToOtherShips(board, row, col, shipSize, direction))
                {
                    board.PlaceShip(row, col, shipSize, direction);
                    placed = true;
                }
                else
                {
                    Console.WriteLine("Złe położenie statku. Spróbuj ponownie.");
                }
            }
            board.Display();
        }
    }
    static bool AdjacentToOtherShips(Board board, int row, int col, int shipSize, char direction)
    {
        if (direction == 'V')
        {
            for (int i = -1; i <= shipSize; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    int newRow = row + i;
                    int newCol = col + j;
                    try
                    {
                        if (board.grid[newRow, newCol] == 'S')
                        {
                            return true;
                        }
                    }
                    catch (Exception)
                    {

                    }
                }
            }
        }
        else if (direction == 'H')
        {
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= shipSize; j++)
                {
                    int newRow = row + i;
                    int newCol = col + j;
                    try
                    {
                        if (board.grid[newRow, newCol] == 'S')
                        {
                            return true;
                        }
                    }
                    catch (Exception)
                    {

                    }
                }
            }
        }

        return false;
    }


    static bool GameIsOver(Player player1, Player player2)
    {
        if (AllShipsSunk(player1.OwnBoard))
        {
            Console.WriteLine($"{player2.Name} wygrywa! Wszystkie statki {player1.Name} zatonęły.");
            return true;
        }
        else if (AllShipsSunk(player2.OwnBoard))
        {
            Console.WriteLine($"{player1.Name} wygrywa! Wszystkie statki {player2.Name} zatonęły.");
            return true;
        }
        return false;
    }

    static bool AllShipsSunk(Board board)
    {
        for (int i = 0; i < board.grid.Length; i++)
        {
            for (int j = 0; j < board.grid.Length; j++)
            {
                if (board.grid[i, j] == 'S')
                {
                    return false; 
                }
            }
        }
        return true;
    }
}